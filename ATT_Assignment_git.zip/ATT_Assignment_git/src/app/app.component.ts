
// ATT

import { Component } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import {throwError} from 'rxjs';
import {catchError, map} from 'rxjs/operators';


@Component({
  //moduleId: module.id,
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["app.component.css"]
})
export class AppComponent {
  title = "Welcome to Giphy Search Option";
  link = "http://api.giphy.com/v1/gifs/search?api_key=dc6zaTOxFJmzC&q=";
  http: HttpClient;
  giphies: any;;

  constructor(http: HttpClient) {
    this.http = http;
  }

  performSearch(searchTerm: HTMLInputElement): void {
    var apiLink = this.link + searchTerm.value;

    this.http.get(apiLink).subscribe(res => {
      this.giphies = JSON.parse(JSON.stringify(res)).data;
      //console.log(this.giphies);
    });
  }

  // let editors = BonsaiTextEditor.editorFactory();
  showGiphy(){
    var x = document.getElementById("giphy");
      x.style.display = "block";
  }
  

}
